var substringMatcher = function(strs) {
return function findMatches(q, cb) {
var matches, substringRegex;
 
// an array that will be populated with substring matches
matches = [];
 
// regex used to determine if a string contains the substring `q`
substrRegex = new RegExp(q, 'i');
 
// iterate through the pool of strings and for any string that
// contains the substring `q`, add it to the `matches` array
$.each(strs, function(i, str) {
if (substrRegex.test(str)) {
matches.push(str);
}
});
 
cb(matches);
};
};



var reasonList = [

'PROVED: Blue Badge application submitted',
'PROVED: Long-term loss of use of both arms',
'PROVED: Substantial & long-term effect on walking ability (BB)',
'PROVED: Children under three (bulky equipment)',
'PROVED: Blind / Severely sight impaired',
'PROVED: Lives in borough',
'PROVED: Photo',
'PROVED: BB Appeal Successful',
'PROVED: ATO Decision - Does not qualify for Blue Badge',
'PROVED: Mobility Assessment Unsuccessful - BB',
'PROVED: Lives out of borough',
'PROVED: BB Application Ended',
'PROVED: Timeout exceeded',
'PROVED: Death',
'PROVED: ATO Decision - BB Assessment Required',
'PROVED: Blue Badge renewal submitted',
'PROVED: Appeal panel requested assessment',
'PROVED: Stage 1 appeal requested',
'PROVED: BB Appeal Unsuccessful',
'PROVED: Substitute Badge Application form'

];


var evidenceList = [


'Additional information',
'Appeal Panel Deferral',
'ATO decision',
'Audiology report',
'Bank statement',
'BBIS Application',
'BD8 - Partially sighted',
'BD8 - Severely sight impaired',
'BD8 certificate',
'Birth certificate',
'Births, deaths and marriages certificate',
'Blue Badge',
'Blue Badge (Camden) within last 3 months',
'Blue Badge Application Form',
'Blue Badge Renewal Form',
'Care package',
'Case conference report',
'Certificate of Incorporation',
'Change of Circumstance (CTS',
'Change of name',
'Cheque or Proof of Payment',
'CLC Application Form',
'CLC Renewal Form',
'CLC Written Correspondence',
'CMS Member screenshot',
'Companies House register',
'Company address on letterheaded paper',
'Company Change of Name form',
'Company prospectus',
'Confirmed Receipt CPA',
'Council tax',
'CTS decision',
'CTS operational schedule',
'CTS report',
'CVI - Partially sighted',
'CVI - Severely sight impaired',
'CVI report',
'Death certificate',
'Declaration',
'DPFP (Discretionary) Application Form',
'DPFP (Discretionary) Renewal Form',
'DPFP Application Form',
'DPFP Renewal Form',
'Driving Licence',
'DVLA report',
'DWP confirmation',
'Electoral roll',
'Eligibility score',
'Employer/Education Letter',
'Evidence of blue badge (Any) membership',
'Evidence of blue badge (Camden) membership',
'Evidence of existing Substitute Badge',
'Failed Camden Resident Check',
'FP Hot-listed in Error report',
'Green Badge Application Form',
'Green Badge Renewal Form',
'Halls of Residence',
'House Insurance',
'HRMCDLA letter of entitlement',
'Learning disabilities team report',
'Loss/Theft report form',
'Marriage certificate',
'Medical evidence',
'Medical Evidence - Ineligible to Drive',
'Medical report form',
'Membership Fee Due',
'Mobility assessment report',
'Newspaper obituary',
'NFI Report',
'OPFP Application Form',
'OPFP Renewal Form',
'OPFP request sent before qualifying age',
'Organisational Blue Badge Application Form',
'Organisational Blue Badge Renewal Form',
'Organisational Green Badge Application Form',
'Organisational Green Badge Renewal Form',
'OT assessment report',
'Other proof of blindness',
'Paris export file',
'Passport',
'PATS management approval required',
'Permit needs renewing',
'Photo',
'PlusBus Accessibility Needs Form',
'PlusBus Application Form',
'Plusbus Membership Fee Due',
'PlusBus Renewal Form',
'PNP',
'Post Office Application Form from CMS',
'Request from centre or case manager',
'Risk assessment',
'Scheme Renewed',
'Scootability Application Form',
'ScootAbility Assessors Report',
'Scootability Client Authorisation Forms',
'Scootability Renewal Form',
'Sensory Needs Report',
'Shopmobility Application Form',
'Shopmobility Renewal Form',
'Shopmobility Training Report',
'Signature',
'SNR - Partially sighted',
'SNR - Severely sight impaired',
'Stage 1 appeal form',
'Stage 1 appeal panel correspondence',
'Stage 1 appeal panel report',
'Stage 2 appeal panel report',
'Stage 2 appeal requested',
'Substitute Badge Application form',
'Substitute Badge Renewal form',
'Successful Camden Resident Check',
'System generated evidence of timeout',
'TASC 2011 Renewal Form',
'TASC Application Form',
'TASC Renewal Form',
'Taxicard',
'Taxicard Application Form',
'Taxicard Extra Trips Application Form',
'Taxicard Extra Trips Assessment Form',
'Taxicard Initiated',
'Taxicard Renewal Form',
'Tell us once report',
'Tenancy agreement/housing register',
'TH Taxicard Application',
'Tracesmart Report',
'Tranzacct DPFP membership',
'TV licence',
'Unicard Import',
'Unspecific address evidence',
'Unspecific identity evidence',
'Unsupported Address Evidence',
'Utility bill',
'V5',
'WPMS letter of entitlement',
'Written correspondence from client/carer/relative/solicitor'

];


$('#evidenceList .typeahead').typeahead({
hint: true,
highlight: true,
minLength: 0
},
{
name: 'evidenceList',
source: substringMatcher(evidenceList)
}); 


$('#reasonList .typeahead').typeahead({
hint: true,
highlight: true,
minLength: 0
},
{
name: 'reasonList',
source: substringMatcher(reasonList)
}); 








// template example for search


//***********HTML:*************

 //       <div class="form-group">
  //        <div id="the-basics">
 //           <input class="typeahead form-control" type="text" placeholder="States of USA" />
  //        </div> 
//        </div>

//****************CSS:*************

//#the-basics .tt-menu {
//max-height: 150px;
//background-color:#ccc;
//padding:5px;
//overflow-y: auto;
//} 

//#the-basics .tt-selectable {
//	cursor:pointer
// }


//***************Javascript:***********

//var states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California',
//'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii',
//'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
//'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
//'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
//'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
//'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
//'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
//'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
//];
 
//$('#the-basics .typeahead').typeahead({
//hint: true,
//highlight: true,
//minLength: 0
//},
//{
//name: 'states',
//source: substringMatcher(states)
//}); 
