// General JS
$(document).ready( function() {

$('.collapse').on('shown.bs.collapse', function(){
	$(this).parent().find(".glyphicon-menu-down").removeClass("glyphicon-menu-down").addClass("glyphicon-menu-up");
	//$('html, body').animate({
  //  scrollTop: $(".tab-bottom").offset().top
//},1500);

	}).on('hidden.bs.collapse', function(){
	$(this).parent().find(".glyphicon-menu-up").removeClass("glyphicon-menu-up").addClass("glyphicon-menu-down");
});

$("input[type='checkbox']").change(function(){
    if($(this).is(":checked")){
        $(this).closest(".check-input").addClass("focusBorder").removeClass('labelfocus');
    }else{
        $(this).closest(".check-input").removeClass("focusBorder").removeClass('labelfocus'); 
    }
});

$("input[type='checkbox']").focus(function() {
    $(this).closest(".check-input").addClass('labelfocus');
}).blur(function() { 
   $(this).closest(".check-input").removeClass('labelfocus');
});

$("input[type='radio']").change(function() {
    $('input:radio[name='+$(this).attr('name')+']').closest(".check-radio").removeClass('active');
    $(this).closest(".check-radio").addClass('active').removeClass('labelfocus');
});

$("input[type='radio']").focus(function() {
    $(this).closest(".check-radio").addClass('labelfocus');
}).blur(function() { 
   $(this).closest(".check-radio").removeClass('labelfocus');
});

// Login Page - error messages
$(".loginerror").hide();

  var permitDate = $("a#login");
  var permitId = $("input#id");

  permitDate.on("click", function (e) {
      setTimeout(function () {
      if (permitId.val().length == 0) {
         $(".loginerror").show();
          $(".idlabel").css("color","#a94442").addClass("required");

      } else {
         
       window.location.href = "dashboard.htm";

      }
  }, 1);
 });

// Dashboard Page - sortable modules
$( "#sortable" ).sortable({
cursor: "move",
handle: ".glyphicon-move",
placeholder: "col-lg-6 ui-state-highlight"
});

// Search Page - add remove schemes
$("#select-scheme2").hide();
$("#select-scheme3").hide();

$(".add_scheme2").click(function(){ 
    $(".add_scheme2").hide();
    $("#select-scheme2").show();
    $(".add_scheme3").show();
});

$(".remove_scheme2").click(function(){ 
   $("#select-scheme2").hide();
   $(".add_scheme2").show();
});
 
$(".add_scheme3").click(function(){ 
    $("#select-scheme3").show();
    $(".add_scheme3").hide();
    $(".remove_scheme2").hide();
});

$(".remove_scheme3").click(function(){ 
  $("#select-scheme3").hide();
  $(".add_scheme3").show();
  $(".remove_scheme2").show();
});

// Search Page - Permit Expiry date enable/disable
var permitDate = $(".permit-date input");
var permitExpiry = $(".permit-expiry input");
var permitDate2 = $(".permit-date2 input");
var permitExpiry2 = $(".permit-expiry2 input");
var permitDate3 = $(".permit-date3 input");
var permitExpiry3 = $(".permit-expiry3 input");

permitDate.on("keydown", function (e) {
    setTimeout(function () {
        if (permitDate.val().length == 0) {
            $(".permit-expiry input").prop("disabled", false);

        } else {
            $(".permit-expiry input").prop("disabled", true);
        }
    }, 1);
});

permitExpiry.on("keydown", function (e) {
    setTimeout(function () {
        if (permitExpiry.val().length == 0) {
            $(".permit-date input").prop("disabled", false);

        } else {
            $(".permit-date input").prop("disabled", true);
        }
    }, 1);
});

permitDate2.on("keydown", function (e) {
    setTimeout(function () {
        if (permitDate2.val().length == 0) {
            $(".permit-expiry2 input").prop("disabled", false);

        } else {
            $(".permit-expiry2 input").prop("disabled", true);
        }
    }, 1);
});

permitExpiry2.on("keydown", function (e) {
    setTimeout(function () {
        if (permitExpiry2.val().length == 0) {
            $(".permit-date2 input").prop("disabled", false);

        } else {
            $(".permit-date2 input").prop("disabled", true);
        }
    }, 1);
});

permitDate3.on("keydown", function (e) {
    setTimeout(function () {
        if (permitDate3.val().length == 0) {
            $(".permit-expiry3 input").prop("disabled", false);

        } else {
            $(".permit-expiry3 input").prop("disabled", true);
        }
    }, 1);
});

permitExpiry3.on("keydown", function (e) {
    setTimeout(function () {
        if (permitExpiry3.val().length == 0) {
            $(".permit-date3 input").prop("disabled", false);

        } else {
            $(".permit-date3 input").prop("disabled", true);
        }
    }, 1);
});

// Profile Page - Cancel link reloads view mode
$( "a.profileCancel, button.saveProfile, .reloadAllQueues, .savedmanagedqueues" ).click(function() {
  location.reload();
});

// Profile Page - Disable All inputs in view mode and hide elements
$(".profileAccordion :input, .profileStatus :input").attr("disabled", true);
$(".addedItem").hide()

$( "a.profileUpdate" ).click(function() {
  $(".profile :input").attr("disabled", false);
  $(".profile :input#id, .maincarerContainer :input").attr("disabled", true);
  $(".addedItem").show();
  $(".removeItem").hide();
  $(".disabilitiesContainer").show();
  
});

// Profile Page - Deceased Checkbox
$('.deceased-dates').hide();
  $('.deceasedcheck input[type="checkbox"]').click(function(){
  if ($(this).is(':checked'))
  {
       // alert($(this).val());
        $('.deceased-dates').show();
        $('.profileStatus').css("background-color","#aa8ff5");
  }

  else {
    $('.deceased-dates').hide();
    $('.profileStatus').css("background-color","#dfeef5");
  }

}); 

// Profile Page - Address Picker Modal
$("#loadAddress").hide(); 
$("#pickerContainer").hide(); 

$(".searchAddress").click(function(){
    $("#addressLoader").load("profile.htm #pickerContainerOuter", function(responseTxt, statusTxt, xhr){

    $(".modal-loader").show(); 

        if(statusTxt == "success")
           // alert("External content loaded successfully!");
        	$(".no-search").hide(); 
        	$("#loadAddress").hide(); 
    			$(".manualAddress a, .addressPicker ul li a").click(function(){
    				$("#pickerContainer").hide(); 
    			    $("#loadAddress").show();
    			});

          $("button.backpickerContainer").click(function() {
            $("#pickerContainer").show(); 
            $("#loadAddress").hide();
          });

  			$(".updateAddressPicker").datepicker({ 
  	          numberOfMonths:1
  	        });

          if(statusTxt == "error")
             // alert("Error: " + xhr.status + ": " + xhr.statusText);
          	$(".no-search").show(); 
      });
});

// Profile Page - Relation Picker Modal
$("#loadRelation").hide(); 
$("#relationContainer").hide(); 

$(".searchRelation").click(function(){
    $("#relationLoader").load("profile.htm #relationContainerOuter", function(responseTxt, statusTxt, xhr){

      if(statusTxt == "success")
         // alert("External content loaded successfully!");
        $(".no-search").hide(); 
        $("#loadRelation").hide(); 
        $(".manualRelation a, .relationPicker ul li a").click(function(){
          $("#relationContainer").hide(); 
          $("#loadRelation").show();
      });

      $("button.backrelationContainer").click(function() {
        $("#relationContainer").show(); 
        $("#loadRelation").hide();
      });

      $(".updateRelationPicker").datepicker({ 
            numberOfMonths:1,
            beforeShow: function(input, inst)
          {
              inst.dpDiv.css({marginTop: -input.offsetHeight + 'px', marginLeft: input.offsetWidth + 'px'});
          }
          });

        if(statusTxt == "error")
           // alert("Error: " + xhr.status + ": " + xhr.statusText);
          $(".no-search").show(); 
    });
});

// Profile Page - Popover
$('[data-toggle="popover"]').popover({
    html: true,
    content: function () {
        return $(this).next('.popper-content').html();
    }
});

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        //the 'is' for buttons that trigger popups
        //the 'has' for icons within a button that triggers a popup
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});

$('[data-toggle="offcanvas"]').on('click', function () {

    $('.searchPanel').css("margin-left","0px");

    $('.row-offcanvas').toggleClass('active');

    elem = $(".row-offcanvas");

    if (elem.is (".active")) {
        $('.searchPanel').css("margin-left","30px");
    };

    $(this).text(function(i, v){
       return v === 'Show filters' ? 'Hide filters' : 'Show filters'
    })
   
});

$(".applyFilter").on('click', function(){
  location.reload();
});

$('.flagsContainer ul li a').on('click', function (e) {
    e.preventDefault(); 
    return true;
});

// Profile Page - Adding / Deleting Flags / Datepicker
$('.flagList').on('click', '.deleteFlag', function() {
    $(this).closest('li').remove();
});

$(".validFlagPicker, .dateDeathPicker, .dateNotifiedPicker").datepicker({ 
  numberOfMonths:1
});

// Profile Page - Delete table rows related persons
$('.tableRelations').on('click', '.deleteRelationBtn', function(e){

    if ($(this).closest('table').find('tr').length > 2) {
        $(this).closest('tr').remove();
    }
    else {
       $(this).closest('tr').replaceWith("<tr><td colspan='6'>There are currently no relatives added.</td></tr>");
    } 

});

// Profile Page - checkbox Main carer
$('input.checkboxMain').on('change', function() {
    $('input.checkboxMain').not(this).prop('checked', false);  
});


// Profile Page - Delete table rows alia
$('.extras-table').on('click', '.deleteAliasBtn', function(e){

    if ($(this).closest('table').find('tr').length > 2) {
        $(this).closest('tr').remove();
        $('.maincarerContainer').show();
    }
    else {
       $(this).closest('tr').replaceWith("<tr><td colspan='6'>There are currently no aliases added.</td></tr>");
       $('.maincarerContainer').hide();
    } 

});

// Schemes Page - Send Letter
$(".tableLettersList .removeLetter").hide();

$('.addLetter a').click(function() {
    var tr = $(this).closest('tr').clone();
    $('.tableLettersAttached tbody').append(tr);
    $(".tableLettersAttached .removeLetter").show();
    $(".tableLettersAttached .addLetter, .tableLettersAttached .editLetter").hide();
    $('.tableLettersAttached tr td.noletters').hide();
});

$(".tableLettersAttached").on("click", ".removeLetter a", function() {

    if ($(this).closest('table').find('tr').length > 2 ) {
        $(this).closest('tr').remove();
    }
    else {
      $(this).closest('tr').remove();
      $('.tableLettersAttached tr td.noletters').show();
    } 
});

$(".viewStatesLink").click(function () {
    $(this).text(function(i, v){
       return v === 'View' ? 'Hide' : 'View'
    })
});

$(".selectLetter").hide();

$(".continueJob").on ('click', function () {
  $(".jobMessage").hide();
  $(".selectLetter").show();
});

// Schemes Page - scheme table checkboxes
$('.schemesflagsContainer.inactive, .schemesflagsContainer.unsuccessful').hide();

// Schemes Page - criteria Ajax load
$("#evidenceContainerOuter").hide();

$(".evidenceItem").click(function(){
    $("#evidenceLoader").load("schemes.htm #evidenceContainerOuter", function(responseTxt, statusTxt, xhr) {

        if(statusTxt == "success")
          $(".evidence-upload").show();
          $(".evidence-links, .evidence-table").hide();

          $('#uploadEvidence').change(function(){
            $('#UploadEvidencePath').val($(this).val());
          });

          $(".showEvidenceTable").click(function(){
              $("#loadEvidence").load("schemes.htm .evidence-table", function(responseTxt, statusTxt, xhr){

                  if(statusTxt == "success")
                     //alert("External content loaded successfully!");

                    $(".satisfiedInput input[type=checkbox]").each(function () {
                        $(this).change(function () {
                            if ($(this).is(":checked")) {
                               // alert("dsfsdfs");
                                $(this).closest('tr').toggleClass("highlight", this.checked);
                            }
                            else {
                             $(this).closest('tr').toggleClass("highlight");
                            }
                        });
                    });

                    $(".validInput input[type=checkbox]").each(function () {
                        $(this).change(function () {
                            if ($(this).is(":checked")) {
                                $(this).parent().parent().parent().find('.dateInputField').prop("disabled", "false");
                            }
                            else {
                              $(this).parent().parent().parent().find('.dateInputField').removeAttr("disabled");
                            }
                        });
                    });

                    $(".tableDatePicker").datepicker({   
                      numberOfMonths:1,
                        beforeShow: function(input, inst) {
                            // Handle calendar position before showing it.
                            // It's not supported by Datepicker itself (for now) so we need to use its internal variables.
                            var calendar = inst.dpDiv;

                            // Dirty hack, but we can't do anything without it (for now, in jQuery UI 1.8.20)
                            setTimeout(function() {
                                calendar.position({
                                    my: 'left top',
                                    at: 'left bottom',
                                    collision: 'none',
                                    of: input
                                });
                            }, 1);
                        }
                    });
                          
                  if(statusTxt == "error")
                     // alert("Error: " + xhr.status + ": " + xhr.statusText);
                   $(".evidence-table").hide(); 
              });

          });

        if(statusTxt == "error")
            alert("Error: " + xhr.status + ": " + xhr.statusText);
    });
});



$(".reuseEvidenceTable .satisfiedInput input[type=checkbox]").each(function () {
    $(this).change(function () {
        if ($(this).is(":checked")) {
           // alert("dsfsdfs");
            $(this).closest('tr').toggleClass("highlight", this.checked);
        }
        else {
         $(this).closest('tr').toggleClass("highlight");
        }
    });
});

$(".reuseEvidenceTable .validInput input[type=checkbox]").each(function () {
    $(this).change(function () {
        if ($(this).is(":checked")) {
            $(this).parent().parent().parent().find('.dateInputField').prop("disabled", "false");
        }
        else {
          $(this).parent().parent().parent().find('.dateInputField').removeAttr("disabled");
        }
    });
});

// Permit table - update Permit Modal
$(".permitContainer").hide();

$( "a.updatePermit" ).click(function() {
    $("#permitLoad").load(".permitContainer");
    $(".permitDetails").hide();
    $(".permitContainer").show();
});

// Evidence Modal - file upload
$('#uploadFile').change(function(){
    $('#UploadPath').val($(this).val());
});

// Criteria Table - display on Evidence Modal
$(".criteria-table").hide();

$(".showCriteriaTable").click(function(){

    $("#loadCriteria").load("services.htm .criteria-table", function(responseTxt, statusTxt, xhr){

        $(".generalPicker").datepicker({ });

        if(statusTxt == "success")
           //alert("External content loaded successfully!");

          $(".satisfiedInput input[type=checkbox]").each(function () {
              $(this).change(function () {
                  if ($(this).is(":checked")) {
                     // alert("dsfsdfs");
                      $(this).closest('tr').toggleClass("highlight", this.checked);
                  }
                  else {
                   $(this).closest('tr').toggleClass("highlight");
                  }
              });
          });

          $(".validInput input[type=checkbox]").each(function () {
              $(this).change(function () {
                  if ($(this).is(":checked")) {
                      $(this).parent().parent().parent().find('.dateInputField').prop("disabled", "false");
                  }
                  else {
                    $(this).parent().parent().parent().find('.dateInputField').removeAttr("disabled");
                  }
              });
          });

          $(".tableDatePicker").datepicker({   
            numberOfMonths:1,
              beforeShow: function(input, inst) {
                  // Handle calendar position before showing it.
                  // It's not supported by Datepicker itself (for now) so we need to use its internal variables.
                  var calendar = inst.dpDiv;

                  // Dirty hack, but we can't do anything without it (for now, in jQuery UI 1.8.20)
                  setTimeout(function() {
                      calendar.position({
                          my: 'left top',
                          at: 'left bottom',
                          collision: 'none',
                          of: input
                      });
                  }, 1);
              }
          });
                
        if(statusTxt == "error")
           // alert("Error: " + xhr.status + ": " + xhr.statusText);
         $(".criteria-table").hide(); 
    });

});

// Profile - Swap watch text
$(".watchItem").click(function () {
    $(this).text(function(i, v){
       return v === 'Watch' ? 'Unwatch' : 'Watch'
    })
});

$(".answer2, .answer3, .answer4, .answer5").hide(); 

$('[class^="question"]').on('click', function(e){
    e.preventDefault();
    var numb = this.className.replace('question', '');
    $('[class^="answer"]').hide();
    $('.answer' + numb).show();
});

// Appointments Calendar - disable all radio buttons
$('.appointments .appointments-container input[type="radio"]').prop("disabled","disabled");

// Appointments Calendar - Load appointment day panel
  $("#venueType").on("change", function() {
      id = "venueview_" + $(this).val() + "";
      $("#" + id).show().siblings().hide()
  }).change();

// Bookings Calendar - Load Booking panel
$("#bookingDetailsLoad").load("bookingPanel.htm", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
      //alert("External content loaded successfully!");

$('#appointment1').change(function(){
    var selected = $(this).find('option:selected');
   $('#appointment1text').html(selected.text()); 
}).change();

//$('#appointment2').change(function(){
    //var selected = $(this).find('option:selected');
   //$('#appointment2text').html(selected.text()); 
//}).change();

$('[data-toggle="popover"]').popover({
    html: true,
    content: function () {
        return $(this).next('.popper-content').html();
    }
});

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        //the 'is' for buttons that trigger popups
        //the 'has' for icons within a button that triggers a popup
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});

$('#proficiency1').change(function(){
    var selected = $(this).find('option:selected');
   $('#proficiencytext').html(selected.text()); 
}).change();

$("#notes").keyup(function(){
    if($(this).val() == ""){
       $('#notesslot').hide();
    }else{
       $('#notesslot').show();
    }
   $("#notesslot").html( "Notes: "+$(this).val()+" ");
});

// Bookings Calendar - load into Appointment details panel
$(".appointmenteditContainer").hide();

$(".bookappointment").on('click', function(){

    if($('.appointments-container input[type="radio"]').is(":checked")) {

       $('.appointments-container input[type="radio"]').prop("disabled","disabled");
       $('.appointments-container input[type="radio"]:checked + label').addClass("checkedAppointment");
       $('.appointments-container .radio-label').css("cursor","default");
       $('.appointmentDetailsContainer').hide();
       $(".appointmenteditContainer").show();
       $(".weekNav").hide();

    }

    else {

      $("#appointmentDetailsContent").hide();
      $('#selectAppointment').modal('show');

    }

});

$(".radio-label").on('click', function(){

    $('#slotOptionsModal').modal('show');

});

// Bookings Calendar - edit or update an appointment
$(".editAppointment").on('click', function(){

  $(".appointmentDetailsContainer").show();
  $(".appointmenteditContainer").hide();
  $(".appointmentstatusContainer").removeClass('hideAppointmentstatus').addClass('showAppointmentstatus');

});

$(".doneReport").on('click', function(){

  $(".reportAdded").removeClass('hideReportstatus').addClass('showReportstatus');
  $(".writeReport").hide();

});

// Bookings status dropdown
$('.appointmentContent').hide();

$('#appointmentstatus').change(function() {
    var selected = $(this).find('option:selected');
    $('.appointmentContent').hide();
    $('.' + $(this).val()).show(); 
    $('#statusslottext').html("Your appointment status is "+selected.text()+" "); 
}).change();

// Report Modal - report select options
$("#reportType").on("change", function() {
    id = "related_" + $(this).val() + "";
    $("#" + id).show().siblings().hide()
}).change();

// Report Modal - report file upload
$('#uploadreportFile').change(function(){
    $('#UploadreportPath').val($(this).val());
});

});

// Bookings Calendar - Booking
$('.appointments-container input[type="radio"]').addClass('input_hidden');

$('.appointments-container input[type="radio"]').click(function() {
    $(this).each(function() {
      var timeslot = $(this).attr("id");
      var dayslot = $(this).closest(".day-column").find(".date-heading");
      $('#appointmentslot').html($("label[for='"+timeslot+"']").text());
      $('#dayslot').html((dayslot).text());
    });
});

// Bookings Calendar - reload panel from modal
$(".selectAppointmentButton").on('click', function(){
  location.reload();
});

// OT Appointments Tab loads in Calendar by Location
    $("#loadLocation1Details").load("location1.htm", function(responseTxt, statusTxt, xhr){

        if(statusTxt == "success")
          //alert("External content loaded successfully!");

          $('.appointments-container input[type="radio"]').addClass('input_hidden');
          $('.appointments-container input[type="radio"]').prop("disabled","disabled");

          $(".checkAppointmentsContainer .date-heading").click(function() {
            $(".checkAppointmentsContainer .date-heading").removeClass("active");
              $(this).addClass("active");
          });

          $(".daycontent2, .daycontent3, .daycontent4, .daycontent5").hide(); 

          $('[class^="datelink"]').on('click', function(e){
            e.preventDefault();
            var numb = this.className.replace('datelink', '');
            $('[class^="daycontent"]').hide();
            $('.daycontent' + numb).show();
          });

          $('.manageWeekContainer').hide();

            $(".slot-available .close").on('click', function() {
              $(this).closest(".slot-status").find(".slot-available").addClass("hide");
              $(this).closest(".slot-status").find(".slot-unavailable").css("display","block").removeClass("hide");
              $(this).closest(".slot-status").find(".slot-unavailable a").removeClass("hide");
            });

            $(".slot-unavailable .open").on('click', function() {
              $(this).closest(".slot-status").find(".slot-available").removeClass("hide");
              $(this).parent().hide();
            });

          $(".manageWeek").on('click', function(){
            $(".checkAppointmentsContainer").hide();
            $('.manageWeekContainer').show();

              // Bookings Calendar - Booking
              $('.appointments-container input[type="radio"]').addClass('input_hidden');

              $('.appointments-container input[type="radio"]').click(function() {
                  $(this).each(function() {
                    var timeslot = $(this).attr("id");
                    var dayslot = $(this).closest(".day-column").find(".date-heading");
                    $('#appointmentslot').html($("label[for='"+timeslot+"']").text());
                    $('#dayslot').html((dayslot).text());
                  });
              });

              $(".slot-unavailable .open").on('click', function() {
                $(this).closest(".slot-status").find(".slot-available").removeClass("hide");
                $(this).parent().hide();
              });

              $(".slot-available .close").on('click', function() {
                $(this).closest(".slot-status").find(".slot-available").addClass("hide");
                $(this).closest(".slot-status").find(".slot-unavailable").css("display","block");
                $(this).closest(".slot-status").find(".slot-unavailable").removeClass("hide");
              });

              $(".appointementDayTitle .open").on('click', function() {

                $(this).closest(".day-column").find(".slot-available").removeClass("hide");
                $(this).closest(".day-column").find(".slot-unavailable").hide();
                $(this).hide();

                $(".slot-unavailable .open").on('click', function() {
                  $(this).closest(".slot-status").find(".slot-available").removeClass("hide");
                  $(this).parent().hide();
                });

                $(".slot-available .close").on('click', function() {
                  $(this).closest(".slot-status").find(".slot-available").addClass("hide");
                  $(this).closest(".slot-status").find(".slot-unavailable").css("display","block");
                  $(this).closest(".slot-status").find(".slot-unavailable a").removeClass("hide");
                });

              });

          });

          $(".saveWeek").on('click', function(){
              $(".checkAppointmentsContainer").show();
              $('.manageWeekContainer').hide();
          });

          $(".location2").click(function(){
              $("#loadLocation2Details").load("location2.htm", function(responseTxt, statusTxt, xhr){

                  if(statusTxt == "success")
                    //alert("External content loaded freddie!");

                    $('.appointments-container input[type="radio"]').addClass('input_hidden');
                    $('.appointments-container input[type="radio"]').prop("disabled","disabled");

                    $(".checkAppointmentsContainer .date-heading").click(function() {
                      $(".checkAppointmentsContainer .date-heading").removeClass("active");
                        $(this).addClass("active");
                    });

                    $(".daycontent2, .daycontent3, .daycontent4, .daycontent5").hide(); 

                    $('[class^="datelink"]').on('click', function(e){
                      e.preventDefault();
                      var numb = this.className.replace('datelink', '');
                      $('[class^="daycontent"]').hide();
                      $('.daycontent' + numb).show();
                    });

                    $('.manageWeekContainer').hide();

                    $(".manageWeek").on('click', function(){
                      $(".checkAppointmentsContainer").hide();
                      $('.manageWeekContainer').show();

                        // Bookings Calendar - Booking

                        $('.appointments-container input[type="radio"]').addClass('input_hidden');

                        $('.appointments-container input[type="radio"]').click(function() {
                            $(this).each(function() {
                              var timeslot = $(this).attr("id");
                              var dayslot = $(this).closest(".day-column").find(".date-heading");
                              $('#appointmentslot').html($("label[for='"+timeslot+"']").text());
                              $('#dayslot').html((dayslot).text());
                            });
                        });

                        $(".slot-unavailable .open").on('click', function() {
                          $(this).closest(".slot-status").find(".slot-available").removeClass("hide");
                          $(this).parent().hide();
                        });


                        $(".slot-available .close").on('click', function() {
                          $(this).closest(".slot-status").find(".slot-available").addClass("hide");
                          $(this).closest(".slot-status").find(".slot-unavailable").css("display","block");
                          $(this).closest(".slot-status").find(".slot-unavailable").removeClass("hide");
                        });

                        $(".appointementDayTitle .open").on('click', function() {

                          $(this).closest(".day-column").find(".slot-available").removeClass("hide");
                          $(this).closest(".day-column").find(".slot-unavailable").hide();
                          $(this).hide();

                          $(".slot-unavailable .open").on('click', function() {
                            $(this).closest(".slot-status").find(".slot-available").removeClass("hide");
                            $(this).parent().hide();
                          });

                          $(".slot-available .close").on('click', function() {
                            $(this).closest(".slot-status").find(".slot-available").addClass("hide");
                            $(this).closest(".slot-status").find(".slot-unavailable").css("display","block");
                            $(this).closest(".slot-status").find(".slot-unavailable a").removeClass("hide");
                          });

                        });

                    });

                    $(".saveWeek").on('click', function(){
                        $(".checkAppointmentsContainer").show();
                        $('.manageWeekContainer').hide();
                    });

                  if(statusTxt == "error")
                     alert("Error: " + xhr.status + ": " + xhr.statusText);

              });
          });
  
        if(statusTxt == "error")
           alert("Error: " + xhr.status + ": " + xhr.statusText);

    });

// New Client Page - Add New Client
$("#loadNewclient").hide(); 
$("#newClientContainerOuter").hide(); 

$(".addNewclient").click(function(){
    $("#newClientLoader").load("newclient.htm #newClientContainerOuter", function(responseTxt, statusTxt, xhr){

        if(statusTxt == "success")
          //alert("External content loaded successfully!");
          $(".no-clientSearch").hide(); 
          $("#loadNewclient").hide(); 
          $(".manualNewclient a").click(function(){
            $("#newClientContainer").hide(); 
            $("#loadNewclient").show();
            $(".generalPicker").datepicker({ });
          });
          $("a.backnewClientContainer").click(function() {
            $("#newClientContainer").show(); 
            $("#loadNewclient").hide();
          });

          $(".selectAddressLink a").click(function() {
            $('#selectaddressModal').modal('show');
          });
                    
          $(".newClientDatePicker").datepicker({ 
              numberOfMonths:1,
              beforeShow: function(input, inst)
              {
                  inst.dpDiv.css({marginTop: -input.offsetHeight + 'px', marginLeft: input.offsetWidth + 'px'});
              }
          });

        if(statusTxt == "error")
           alert("Error: " + xhr.status + ": " + xhr.statusText);
          $(".no-search").show(); 
    });
});

// TimeSlot
$("#timeSlotLoad").load("timeslotPanel.htm", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
      //alert("External content loaded successfully!");

  $('#appointment1').change(function(){
      var selected = $(this).find('option:selected');
     $('#appointment1text').html(selected.text()); 
  }).change();

  $('#appointment2').change(function(){
      var selected = $(this).find('option:selected');
     $('#appointment2text').html(selected.text()); 
  }).change();

  $('#proficiency1').change(function(){
      var selected = $(this).find('option:selected');
     $('#proficiencytext').html(selected.text()); 
  }).change();

  $("#notes").keyup(function(){
      if($(this).val() == ""){
         $('#notesslot').hide();
      }else{
         $('#notesslot').show();
      }
     $("#notesslot").html( "Notes: "+$(this).val()+" ");
  });

$('[data-toggle="popover"]').popover({
    html: true,
    content: function () {
        return $(this).next('.popper-content').html();
    }
});

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        //the 'is' for buttons that trigger popups
        //the 'has' for icons within a button that triggers a popup
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});

// Bookings Calendar - load into Appointment details panel
$('.appointmentDetailsContainer').hide();

$(".bookappointment").on('click', function(){

    if($('.appointments-container input[type="radio"]').is(":checked")) {

       $('.appointments-container input[type="radio"]').prop("disabled","disabled");
       $('.appointments-container input[type="radio"]:checked + label').addClass("checkedAppointment");
       $('.appointments-container .radio-label').css("cursor","default");
       $('.appointmentDetailsContainer').hide();
       $(".appointmenteditContainer").show();

    }

    else {

      $("#appointmentDetailsContent").hide();
      $('#selectAppointment').modal('show');

    }

});

$(".radio-label").on('click', function(){

  $('#slotOptionsModal').modal('show');

});

// Bookings Calendar - edit or update an appointment
$(".editAppointment").on('click', function(){

  $(".appointmentDetailsContainer").show();
  $(".appointmenteditContainer").hide();
  $(".appointmentstatusContainer").removeClass('hideAppointmentstatus').addClass('showAppointmentstatus');

});

$(".doneReport").on('click', function(){

  $(".reportAdded").removeClass('hideReportstatus').addClass('showReportstatus');
  $(".writeReport").hide();

});

// Bookings status dropdown
$('.appointmentContent').hide();

$('#appointmentstatus').change(function() {
    var selected = $(this).find('option:selected');
    $('.appointmentContent').hide();
    $('.' + $(this).val()).show(); 
    $('#statusslottext').html("Your appointment status is "+selected.text()+" "); 
}).change();

// Report Modal - report select options
$("#reportTypeSlot").on("change", function() {
    id = "related1_" + $(this).val() + "";
    $("#" + id).show().siblings().hide()
}).change();

// Report Modal - report file upload
$('#uploadreportFile').change(function(){
    $('#UploadreportPath').val($(this).val());
});

});

// Search results - select/check all inputs in table
$(".selectAllSearchInput input").change(function () {
  $(".tableSearchResults td input:checkbox").prop('checked', $(this).prop("checked"));
});

$('label.saveAllPages').on( "click", function () {
  var checked = $('input', this).is(':checked');
  $('span', this).text(checked ? 'Deselect all pages' : 'Select all pages');
});

$('label.savePageResults').on( "click", function () {
  var checked = $('input', this).is(':checked');
  $('span', this).text(checked ? 'Deselect page results' : 'Select page results');
});

$("input#savePageResults").change(function () {
  $(".tableSearchResults td input:checkbox").prop('checked', $(this).prop("checked"));
});

$(".mergeProfilesAction, .addPermitAction").hide();

$("table#searchResultsTable input").change(function () {

  var showSearchActions = $(".tableSearchResults td input:checked").length; 

  if ( showSearchActions === 1 )
   {
     $(".addPermitAction").show();
    }
  else {
    $(".addPermitAction").hide();
  }

  if ( showSearchActions === 2 )
   {
     $(".mergeProfilesAction").show();
    }
  else {
    $(".mergeProfilesAction").hide();
  }

});

// Saved search page - Delete table rows related persons
$('.savedsearch-table').on('click', '.deletesavedSearchBtn', function(e){

    if ($(this).closest('table').find('tr').length > 2) {
        $(this).closest('tr').remove();
    }
    else {
       $(this).closest('tr').replaceWith("<tr><td colspan='4'>There are currently no saved searches.</td></tr>");
    } 

});

$("input.toggleEdit, textarea.toggleEdit").prop("disabled", true);

$( ".editButton" ).on('click', function() {
  $("input.toggleEdit, textarea.toggleEdit").prop("disabled", false);
});

// Search results - select/check all inputs in table
$(".selectAllInput input").change(function () {

  $(".tableQueueResults td input:checkbox").prop('checked', $(this).prop("checked"));

});

// Queue items - check and remove item from the table
$(".selectAllQueueInput input").change(function () {
  $("#tableQueueResultsTable td input:checkbox").prop('checked', $(this).prop("checked"));
});

$('label.selectallqueues').on( "click", function () {
  var checked = $('input', this).is(':checked');
  $('span', this).text(checked ? 'Deselect all queues' : 'Select all queues');
});

$('label.selectallcases').on( "click", function () {
  var checked = $('input', this).is(':checked');
  $('span', this).text(checked ? 'Deselect all cases' : 'Select all cases');
});

  $("#removeQueueItem").on("click",function(){
     $('.tableQueueResults table input:checked').each(function() {
      $(this).closest('tr').remove();
     return false;
    });
 }); 

// Queue items - load my dashboard queues
$("#myQueuesTable").hide();
$(".saveMyQueues").hide();

$(".myDashboardQueues a").click(function(){

  $("#myQueuesTableLoad").load("queues.htm #myQueuesTable", function(responseTxt, statusTxt, xhr){

      if(statusTxt == "success")
        //alert("External content loaded successfully!"); 
        $("#allQueuesTable").hide();
        $(".myDashboardQueues").hide();
        $(".saveMyQueues").show();
        $(".selectallqueues").hide();
        $(".queue-actions").hide();

        $("#myQueuesTable input").change(function () {
          var maxAllowed = 6;
          var cnt = $("#myQueuesTable input:checked").length;       
          if (cnt > maxAllowed)
           {
              $(this).prop("checked", "");
              $('#checkedItemsModal').modal('show');
          }

        });

      if(statusTxt == "error")
         alert("Error: " + xhr.status + ": " + xhr.statusText);

  });

});

//$('.selectpicker').selectpicker();

// Administration - scheme management
$(".schemeManagement :input").attr("disabled", true);
$(".schemeManageButton :input").attr("disabled", false);
$(".schemeManagement label").css("cursor", "not-allowed");

$( "a.editScheme" ).click(function() {
  $(".schemeManagement :input").attr("disabled", false);
  $(".schemeManagement label").css("cursor", "pointer");
  $(".addStage label").css("cursor", "default");
  $(".addedItem").show();
  $(".removeItem").hide();
  $(".letterDetail, .schemeDetail").hide();
  return false;
});

$( "a.cancelScheme, button.saveScheme" ).click(function() {
  location.reload();
});

$('.stageElements').addClass("hide"); 

$('.stageInput').on('change', function () {
    if (this.checked) {
        $(this).closest('div').find('.stageElements').removeClass("hide").addClass("show");
    } else {
        $(this).closest('div').find('.stageElements').removeClass("show").addClass("hide");
    }
});

$('.letterDetailContentButton, .closeStagePathPanel').on('click', function(e) {
    e.preventDefault(); 
    $(this).closest('.stagePathPanel').remove();
});

$('.tableSchemeManagement').on('click', '.deleteSchemeBtn', function(e){

    if ($(this).closest('table').find('tr').length > 2) {
        $(this).closest('tr').remove();
    }
    else {
       $(this).closest('tr').replaceWith("<tr><td colspan='6'>There are currently no items added.</td></tr>");
    } 
    
});


$('.tableAnnouncement').on('click', '.deleteAnnounceBtn', function(e){

    if ($(this).closest('table').find('tr').length > 2) {
        $(this).closest('tr').remove();
    }
    else {
       $(this).closest('tr').replaceWith("<tr><td colspan='6'>There are currently no announcements.</td></tr>");
    } 

});


// Datepickers
$(".adminAddressPicker").datepicker({ 
    numberOfMonths:1,
    beforeShow: function(input, inst)
    {
        inst.dpDiv.css({marginTop: -input.offsetHeight + 'px', marginLeft: input.offsetWidth + 'px'});
  }
});

$(".generalPicker").datepicker({ });

}); //end of ready

// var $check = $(".accordionFilterContainer input[type=checkbox]"), el;
// $check
  // .data('checked',0)
  // .click(function(e) {
       
      //  el = $(this);
                
      //  switch(el.data('checked')) {
            
       //     case 0:
        //        el.data('checked',1);
         //       el.prop('checked',true);
          //      break;

          //  case 1:
          //      el.data('checked',2);
          //      el.prop('checked',false);
           //     el.prop('indeterminate',true);                
           //     break;
            
          //  default:  
          //      el.data('checked',0);
          //      el.prop('indeterminate',false);
         //       el.prop('checked',false);
                
     //   }
        
   //  });